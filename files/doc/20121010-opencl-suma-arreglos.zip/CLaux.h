/*
 *
 * 	Auxiliary Functions
 *
 * 	Juan Fraire
 * 	FAMAF
 *
 */

#ifndef CLAUX_H_
#define CLAUX_H_

/// Array Size Constant
#define ARRAY_SIZE 10

#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <iostream>
#include <math.h>
#include <CL/cl.h>

#include <string.h>
#include <stdarg.h>

#include <cstdio>

#include <sstream>

using namespace std;

/*
 *  CreateContext() Looks for the first platform available
 *  and acquires its ID for future use. Then it tries to create
 *  a Context associated with the chosen platform by getting
 *  a GPU type Device ID or a CPU if no GPU available
 *
 *  Note: This is a fairly simple function but here we would include
 *  all inteligence related to find the most proper device for executing
 *  our kernels
 */
cl_context CreateContext()
{
	cl_int errNum;
	cl_uint numPlatforms;
	cl_platform_id firstPlatformId;
	cl_context context = NULL;

	/* First, select an OpenCL platform to run on.
	 * For this example, we simply choose the first available
	 * platform. Normally, you would query for all available
	 * platforms and select the most appropriate one.
	 */
	/// Function Structure:
	/// clGetPlatformIDs(	cl_uint          /* num_entries */,
    /// 					cl_platform_id * /* platforms */,
    /// 					cl_uint *        /* num_platforms */)
	///
	errNum = clGetPlatformIDs(1, &firstPlatformId, &numPlatforms);
	if (errNum != CL_SUCCESS || numPlatforms <= 0)
	{
		cerr << "Failed to find any OpenCL platforms." << endl;
		return NULL;
	}

	/* Next, create an OpenCL context on the platform. Attempt to
	 * create a GPU-based context, and if that fails, try to create
	 * a CPU-based context.
	 * */
	cl_context_properties contextProperties[] =
	{ CL_CONTEXT_PLATFORM, (cl_context_properties) firstPlatformId, 0 };
	/// Function Create Context From Type
	/// clCreateContextFromType(const cl_context_properties * /* properties */,
    /// 						cl_device_type                /* device_type */,
    /// 						void (CL_CALLBACK *     /* pfn_notify*/ )(const char *, const void *, size_t, void *),
    /// 						void *                        /* user_data */,
    /// 						cl_int *                      /* errcode_ret */)
	///
	context = clCreateContextFromType(contextProperties, CL_DEVICE_TYPE_GPU,
			NULL, NULL, &errNum);
	if (errNum != CL_SUCCESS)
	{
		cout << "Could not create GPU context, trying CPU..." << endl;
		context = clCreateContextFromType(contextProperties, CL_DEVICE_TYPE_CPU,
				NULL, NULL, &errNum);
		if (errNum != CL_SUCCESS)
		{
			cerr << "Failed to create an OpenCL GPU or CPU context.";
			return NULL;
		}
	}
	return context;
}

/*
 * CreateCommandQueue () returns a command queue associated with a given
 * context and device. It initilize the device as well
 */
cl_command_queue CreateCommandQueue(cl_context context, cl_device_id *device)
{
	cl_int errNum;
	cl_device_id *devices;
	cl_command_queue commandQueue = NULL;
	size_t deviceBufferSize = -1;

	/// First get the size of the devices buffer
	/// This funtions returns in deviceBufferSize the number of
	/// available devices in the context
	///
	/// Function Structure:
	///	clGetContextInfo(	cl_context         /* context */,
    /// 					cl_context_info    /* param_name */,
    /// 					size_t             /* param_value_size */,
    /// 					void *             /* param_value */,
    /// 					size_t *           /* param_value_size_ret */)
	///
	errNum = clGetContextInfo(context, CL_CONTEXT_DEVICES, 0, NULL,
			&deviceBufferSize);
	if (errNum != CL_SUCCESS)
	{
		cerr << "Failed call toclGetContextInfo	(...,CL_CONTEXT_DEVICES,...)";
		return NULL;
	}
	if (deviceBufferSize <= 0)
	{
		cerr << "No devices available.";
		return NULL;
	}

	/// Allocate memory for the devices buffer
	devices = new cl_device_id[deviceBufferSize / sizeof(cl_device_id)];
	errNum = clGetContextInfo(context, CL_CONTEXT_DEVICES, deviceBufferSize,
			devices, NULL);
	if (errNum != CL_SUCCESS)
	{
		cerr << "Failed to get device IDs";
		return NULL;
	}

	///	In this example we chose the first available device. On a real program
	///	you would chose the most proper (powerful?) device.
	///	This decision is based in OpenCL queries
	/// Function Structure:
	///
	/// clCreateCommandQueue(	cl_context                     /* context */,
    /// 						cl_device_id                   /* device */,
    /// 						cl_command_queue_properties    /* properties */,
    /// 						cl_int *                       /* errcode_ret */)
	///
	commandQueue = clCreateCommandQueue(context, devices[0], 0, NULL);
	if (commandQueue == NULL)
	{
		cerr << "Failed to create commandQueue for device 0";
		return NULL;
	}
	*device = devices[0];
	delete[] devices;
	return commandQueue;
}

/*
 *  CreateProgram reads the file fileName and return the program
 *  from it in a given context and for a given device. Then the
 *  program is compiled for all devices
 */
cl_program CreateProgram(cl_context context, cl_device_id device,
		const char* fileName)
{
	cl_int errNum;
	cl_program program;
	ifstream kernelFile(fileName, ios::in);
	if (!kernelFile.is_open())
	{
		cerr << "Failed to open file for reading: " << fileName << endl;
		return NULL;
	}
	ostringstream oss;
	oss << kernelFile.rdbuf();
	string srcStdStr = oss.str();
	const char *srcStr = srcStdStr.c_str();

	/// Create Program object:
	///
	/// clCreateProgramWithSource(	cl_context        /* context */,
	/// 							cl_uint           /* count */,
	/// 							const char **     /* strings */,
	/// 							const size_t *    /* lengths */,
	/// 							cl_int *          /* errcode_ret */)
    ///
	program = clCreateProgramWithSource(context, 1, (const char**) &srcStr,
			NULL, NULL);
	if (program == NULL)
	{
		cerr << "Failed to create CL program from source." << endl;
		return NULL;
	}
	errNum = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if (errNum != CL_SUCCESS)
	{
		/// Determine the reason for the error
		char buildLog[16384];
		clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG,
				sizeof(buildLog), buildLog, NULL);
		cerr << "Error in kernel: " << endl;
		cerr << buildLog;
		clReleaseProgram(program);
		return NULL;
	}
	return program;
}

/*
 *  CreateMemObjetcs() Creates the 3 Buffers we are using in this example.
 *  For Buffers of arrays A and B, we pass the CL_MEM_COPY_HOST_PTR flag
 *  indicating the OpenCL Implementation to copy the values of the arrays
 *  to the buffers.
 *  This allows us to avoid clEnqueueWriteBuffer commands for
 *  this two initial buffers
 */
bool CreateMemObjects(cl_context context, cl_mem memObjects[3], float *a,
		float *b)
{
	/// Create Buffer function:
	/// clCreateBuffer(	cl_context   /* context */,
    /// 				cl_mem_flags /* flags */,
	/// 				size_t       /* size */,
	/// 				void *       /* host_ptr */,
	/// 				cl_int *     /* errcode_ret */)
    ///
	memObjects[0] = clCreateBuffer(context,
			CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, sizeof(float) * ARRAY_SIZE,
			a, NULL);
	memObjects[1] = clCreateBuffer(context,
			CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, sizeof(float) * ARRAY_SIZE,
			b, NULL);
	memObjects[2] = clCreateBuffer(context, CL_MEM_READ_WRITE,
			sizeof(float) * ARRAY_SIZE, NULL, NULL);
	if (memObjects[0] == NULL || memObjects[1] == NULL || memObjects[2] == NULL)
	{
		cerr << "Error creating memory objects." << endl;
		return false;
	}
	return true;
}

/*
 * Cleanup Function to release all created objets
 * todo!
 */
void Cleanup(cl_context context, cl_command_queue commandQueue,
		cl_program program, cl_kernel kernel, cl_mem memObjects[3])
{

}

#endif /* AUXFUNC_H_ */

